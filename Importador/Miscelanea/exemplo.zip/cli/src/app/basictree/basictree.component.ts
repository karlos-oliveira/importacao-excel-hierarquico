import { Component } from '@angular/core';
import { ITreeOptions } from 'angular-tree-component';
import axios from 'axios';

import * as XLSX from 'xlsx';

type AOA = any[][];

@Component({
  selector: 'app-basictree',
  template: `

  <div style="margin: 15px;">
    <input type="radio" (change)="setModoTree(1)"  name="modoTree">
    <label>Carregar Importação</label>
    <input type="radio" (change)="setModoTree(2)"  name="modoTree">
    <label>Importar Excel</label>
  </div>

  <div *ngIf="modoTree == 1">
    <select style="margin:15px" [(ngModel)]="IdImport">
      <option value="">Selecione</option>
      <option *ngFor="let import of importacoes" value="{{import.idImportacao}}" >{{import.dataImportacaoUTC}}</option>
    </select>

   <button type="button" (click)="carregarImportacao()" style="margin:15px;">Carregar importação</button>
  </div>

  <div *ngIf="modoTree == 2">
    <div style="margin: 15px;">
      <span>Escolha o excel para importar </span>
      <input type="file" (change)="onFileChange($event); trataExcelParaEnvio($event);">
    </div>
  <div style="display:flex">
    <fieldset *ngIf="data.length > 0" style="display: inline;float: left;margin: 15px;">
      <legend>Coluna de Agrupadores</legend>
      <div *ngFor="let row of data">
        <input type="checkbox" (change)="onAgrupadores(row)" name="{{row}}">
        <label>{{row}}</label>
      </div>
    </fieldset>

    <fieldset *ngIf="listAmbiente.length > 0" style="display: inline;float: left;margin: 15px;">
      <legend>Coluna Ambiente Final</legend>
      <div *ngFor="let row of listAmbiente">
        <input type="radio" (change)="onListAmbiente(row)"  name="AmbienteFinal">
        <label>{{row}}</label>
      </div>
    </fieldset>

    <fieldset *ngIf="listTipoAmbiente.length > 0" style="display: inline;margin: 15px;">
      <legend>Coluna Tipo Ambiente</legend>
      <div *ngFor="let row of listTipoAmbiente">
        <input type="radio" (change)="onListTipoAmbiente(row)"  name="TipoAmbienteFinal">
        <label>{{row}}</label>
      </div>
    </fieldset>

    </div>

    <button type="button" (click)="enviarParaAPI()" style="margin:15px;">Importar</button>
    </div>

    <div style="margin:15px">
      <tree-root  [focused]="true" [nodes]="nodes.filhos" [options]="options"></tree-root>
    </div>

    <br>
    
    
    `,
  styles: ['basic.css']
})
export class BasicTreeComponent {

  nodes = {};
  importacoes = [];
  IdImport = "";
  modoTree;
  
  dominio = "https://gateway-dev.zellar.com.br";
  // dominio = "http://localhost:58939";

  body = {};
  header = {};
  agrupadores = [];
  listAmbiente = [];
  listTipoAmbiente = [];

  campoAmbiente = "";
  campoTipoAmbiente = "";

  data: AOA = [];
  arquivo;

  token = "Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImExNzI2ZWZiNWNjOTdiNjdiZjg4YWFmY2IwZjJhZTI1IiwidHlwIjoiSldUIn0.eyJuYmYiOjE1NzY2MTIyMzcsImV4cCI6MTU3OTIwNDIzNywiaXNzIjoiaHR0cHM6Ly9pZGVudGl0eS1zZXJ2ZXItZGV2LnplbGxhci5jb20uYnIiLCJhdWQiOlsiaHR0cHM6Ly9pZGVudGl0eS1zZXJ2ZXItZGV2LnplbGxhci5jb20uYnIvcmVzb3VyY2VzIiwibW9sdHJlcy5hY2Vzc28uYXBpIl0sImNsaWVudF9pZCI6IldlYiBaZWxsYXIiLCJzdWIiOiI0YTM1OThmZS04YWEwLTQzMzEtYjY5MC02YmQwMzZhMzI0ZTgiLCJhdXRoX3RpbWUiOjE1NzY2MTIyMzcsImlkcCI6ImxvY2FsIiwiYWNjb3VudCI6InplbGxhcjIiLCJpZEFjY291bnQiOiI4RTZFQjYzMi1CNzA3LTQxM0YtQTE1Mi0zQ0ZGRDFGOTgyQjUiLCJzY29wZSI6WyJvcGVuaWQiLCJwcm9maWxlIiwicm9sZXMiLCJtb2x0cmVzLmFjZXNzby5hcGkuZnVsbCIsIm9mZmxpbmVfYWNjZXNzIl0sImFtciI6WyJwd2QiXX0.FgC9YnbcQidfxHp61bZ-IdHQkrWLjLfCM3h0al4khFVpMbTYLnHTpQOCH2M0yAJyF3DKPBCMiO2H5WlSaesy6KtVoM8oxwucH7qJJHEAk20EMmQ9opzzfb7tgYN6E2WDxJVfhQzttmyQmJODsG7DMtGiXif2RjiWPId-xMXfXEmqbhotjDM_Iib5f6s5RYyQZPjd4sUSFNA4MuUSeD-ppgDWRuZLIys3bQGZBoguzvmnQUPLNM-oY29vebHhQQ9E1A4ntfdhELGyJrJeErhBj335b7X_reAY6s994rCy9UBcyt_dqXlQxlrcYvmmKTinnbikj8pPEu4AJlw9g-R3DQ";

  setModoTree(param){
    this.modoTree = param;
    this.nodes = {};

    if(param == 1){
      axios({
        method: 'get', // verbo http
        url: this.dominio + "/api/v1/importador/importacao-ambiente", // url
        // data: this.body,
        headers: {"Authorization": this.token}
      })
      .then(response => {
          this.importacoes = response.data;
      })
      .catch(error => {
          console.log(error)
      })
    }
  }

  onAgrupadores(campo){

    if(!this.agrupadores.includes(campo))
    {
      this.agrupadores.push(campo);
      this.listAmbiente = this.data.filter(x => !this.agrupadores.includes(x));
    }
  }
  
  onListAmbiente(campo){
    this.campoAmbiente = campo;
    this.listTipoAmbiente = this.listAmbiente.filter(x => x !== this.campoAmbiente);
  }

  onListTipoAmbiente(campo){
    this.campoTipoAmbiente = campo;
  }

  onFileChange(evt: any) {
    /* wire up file reader */
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      // this.arquivo = e.target.result;
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      this.data = <AOA>(XLSX.utils.sheet_to_json(ws, { header: 1 }))[0];
      console.log(this.data);

      // this.trataExcelParaEnvio(target.files[0]);
    };
    reader.readAsBinaryString(target.files[0]);
  }

  trataExcelParaEnvio(event){
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
        this.arquivo = reader.result.toString().split(',')[1];
    };
  }

  carregarImportacao(){
    axios({
      method: 'get', // verbo http
      url: this.dominio + "/api/v1/importador/importacao-ambiente/" + this.IdImport, // url
      // data: this.body,
      headers: {"Authorization": this.token}
    })
    .then(response => {
        // console.log(response);

        this.nodes = response.data;
    })
    .catch(error => {
        console.log(error)
    })
  }

  enviarParaAPI(){

    this.body = {
      "agrupadores": this.agrupadores,
      "campoAmbiente": this.campoAmbiente,
      // "campoObservacao":this.campoTipoAmbiente,
      "campoTipoAmbiente":this.campoTipoAmbiente,
      "worksheetIndex": 1,
      "arquivo": this.arquivo
    };

    axios({
      method: 'post', // verbo http
      url: this.dominio + "/api/v1/importador/importacao-ambiente", // url
      data: this.body,
      headers: {"Authorization": this.token}
    })
    .then(response => {
        this.nodes = response.data;
    })
    .catch(error => {
        console.log(error)
    })
  }

  options: ITreeOptions = {
    displayField: 'descricao',
    idField: 'id',
    childrenField: 'filhos'
  };
}
