entrar na pasta "cli"
rodar "npm install"
rodar "npm start"
acessar no navegador o endereço "http://localhost:4200/#/basic"

Obs: caso queira salvar no banco a importação é necessário um token da zellar, ele deve ser colocado na lina 96 do aquivo "~\cli\src\app\basictree\basictree.component.ts"

FIM